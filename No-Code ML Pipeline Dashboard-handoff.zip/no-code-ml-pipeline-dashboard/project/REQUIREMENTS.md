# No-Code ML Pipeline Dashboard ("Money Printer") — Requirements

A no-code interface for business/analytics users to train, evaluate, govern, and
run ML models against warehouse tables. The current artifact is a clickable
front-end demo; this document also specifies the backend the real product needs.

---

## 1. Core concepts

- **Experiment** — a named training job bound to a feature table + a label. Holds
  one or more **runs**, a leaderboard, and generated **predictions**.
- **Run** — one trained model (algorithm + feature set + hyperparameters +
  metrics). Runs are grouped into **rounds** (round 1 = initial training,
  round 2+ = refinements added later).
- **Model governance (MMP)** — an external Model Management Platform. A model
  must be **submitted to MMP and approved** before it can serve predictions.

---

## 2. Training modes

When creating an experiment the user picks one of three modes (segmented toggle):

### Standard (guided wizard, 5 steps)
1. **Training data** — pick feature table, label (same table or a separate label
   table joined on key[s]), and select feature columns.
2. **Algorithms** — choose one or more algorithms. Default: **LightGBM only**,
   others deselected.
3. **Tuning** — feature selection + hyperparameter tuning, both **OFF by default**;
   optional custom search space (off by default).
4. **Data size** — train/val/test split + optional data-size sweep (see §4).
5. **Review** — read-only summary, then run.

### Fast
- LightGBM only. **No feature selection, no hyperparameter tuning.**
- Uses **all feature columns except `cust_num` and `period_id`** (identifiers
  excluded automatically).
- Fixed data config, shown read-only: **all available data**, **random**
  train/val/test split **0.70 : 0.15 : 0.15**.
- Just pick tables + label and run — quickest path to a baseline.

### Auto (formerly "PRO Auto")
- User picks feature table + label table only.
- System **automatically** performs: model selection, feature selection,
  hyperparameter tuning, and data-size selection.
- A pipeline plan is displayed **FYI / read-only** (cannot be edited); each step
  is tagged "AUTO".

**Mode-switch data carry-over:** selections (tables, label, features) made in one
mode must transfer when switching modes (e.g. Fast → Standard shows the same
picked data, and vice-versa).

---

## 3. Feature column selection (Standard, step 1)

- **Search box** to filter columns by name (case-insensitive). While searching,
  all matches show (bypassing the collapse cap); clear (×) button; "no columns
  match" message.
- **Show more / Show less** collapse when there are many columns (cap ~8),
  centered full-width toggle button.
- Feature chips must stay inside their container (no overflow), with ellipsis on
  long names.
- Identifier columns / the label column are locked out of the feature set.

---

## 4. Train / validation / test split & data-size sweep (Standard, step 4)

**Split section (two options):**
1. **Random sampling** — user sets train/val/test ratios (default 70/15/15),
   with a live proportion bar; ratios must sum to 100.
2. **Time-based splitting** — most recent data held out for test; user sets test
   window size (months or days) and number of rolling training repeats (folds).

**No-overlap key (both options, optional):** pick a column (e.g. `cust_id`) that
guarantees the same entity never appears in more than one of train/val/test.

**Data size vs performance test (optional, off by default):**
- **Data-size sweep only** (the sliding-window option was removed): trains on an
  expanding window anchored to the latest data, from a start size stepping up to
  a max, to show how much history actually improves accuracy.

---

## 5. Results / leaderboard & model detail

- **Leaderboard** ranks runs by the experiment's main metric. Keep the best run
  **per algorithm per round** — a refined round-2 model must **not** hide the
  round-1 model.
- Each run detail shows: metrics (accuracy, AUC, F1, precision, recall),
  **Features used**, and — when applicable — **Feature selection output**
  (Kept / Dropped) and **tuned hyperparameters** (with trial count).
- **Show more / Show less** (centered toggle, cap ~12) on every long feature
  list: Features used, FS Kept, FS Dropped, and the refine feature chips.

### Refine & add to experiment
- Available on any selected model that has features + tunable params (especially
  ones trained with feature selection or hyperparameter tuning).
- User can **select top-N features** (ranked by importance; slider; kept green /
  dropped struck-through) and **edit hyperparameters** (seeded from the run's
  tuned values).
- "Add to experiment" trains a **new round** that joins the leaderboard. Existing
  runs are never deleted. A refined model is itself refinable again (its feature
  ranking carries forward), so the capability never disappears.

---

## 6. Model governance (MMP) gate

- A run starts un-submitted. Actions bar states:
  1. **Not submitted** → "Submit to MMP" active; Run prediction disabled.
  2. **Submitted / pending** → "In MMP review" badge + "Check approval status"
     button; Run prediction still disabled.
  3. **Approved** → "Approved in MMP" badge; **Run prediction enabled**.
- "Check approval status" polls MMP; only when MMP returns approved does
  prediction unlock. (Demo: approves on the 2nd check.)
- Leaderboard badges: "In MMP" (pending) / "MMP ✓" (approved).
- Submitting captures MMP version + environment (e.g. Production).

---

## 7. Prediction (inference)

- Only runnable on an **MMP-approved** model.
- User picks an inference table + optional filters, chooses result destination
  (write to table, etc.).
- Prediction feature list shows the model's expected features with the same
  Show more / Show less collapse.

---

## 8. Persistence

- Experiments created in a session **persist across reloads** (browser storage in
  the demo; a real DB in production), including runs, leaderboard, and predictions.
- Built-in seed/example experiments are always present. Two example models are
  pre-approved in MMP for demoing predictions.

---

## 9. Example / seed data

- **GWB FX purchase propensity** — trains on ALL features of `gwb_fx_features_ds`
  (label from `gwb_fx_label_ds`, joined on `cust_num, period_id`), with feature
  selection (large kept/dropped split) and hyperparameter tuning (multiple trials),
  ranked across LightGBM / Random Forest / Logistic Regression.
- **Fraud scoring — Q2** — fraud example; best LightGBM pre-approved in MMP.

---

## 10. Backend requirements (for the real system)

The demo fakes all of the following in the browser. The production backend must
provide:

### Data / metadata
- **Warehouse connector** to list tables and columns (name, type) with row counts;
  read feature + label tables; support joins on one or more keys.
- **Table/column catalog** API for the pickers and the feature search.

### Training service
- Job orchestration for the three modes:
  - **Standard**: train the chosen algorithms with the user's FS/HPT/search-space
    and split config.
  - **Fast**: single LightGBM, all columns minus identifiers (`cust_num`,
    `period_id`), fixed random 70/15/15, no FS/HPT.
  - **Auto**: automated model selection, feature selection, hyperparameter tuning,
    and data-size selection; return the resolved plan for read-only display.
- **Feature selection**: produce a ranked importance list → kept vs dropped.
- **Hyperparameter tuning**: trial-based search; return best params + trial count.
- **Splitting engine**: random ratio split; time-based split (test window in
  months/days + rolling repeats); **no-overlap key** enforcement so an entity
  never spans splits.
- **Data-size sweep**: expanding-window training across sizes → accuracy-vs-size
  curve.
- **Metrics**: accuracy, AUC, F1, precision, recall per run.
- **Rounds/refine**: retrain with a top-N feature subset + edited hyperparameters
  as a new round; keep the feature-importance ranking with the run so it can be
  refined again. Never delete prior runs.
- Async job status + progress reporting for the "running" screen.

### Persistence
- Store experiments, runs (algo, features, params, metrics, round, refine
  lineage), leaderboards, and predictions. Per-user scoping.

### Governance (MMP) integration
- **Submit** a model version to MMP (returns tracking id, version, environment).
- **Check approval status** (pending / approved / rejected).
- Enforce server-side: **no prediction** unless the model version is approved.

### Inference service
- Run batch prediction with an approved model version against a selected table
  (+ filters); validate that inference-table columns cover the model's expected
  features; write results to the chosen destination.

### Scheduling (present in UI)
- Scheduled retrain/inference jobs (frequency, time, days) — needs a scheduler +
  job runner.

---

## 11. Branding / UX notes
- OCBC red (#e2231a) primary; dark ink (#181a1f); JetBrains Mono for
  data/column/param values.
- Read-only fixed-config cards for Fast and Auto modes.
- All long chip lists use the same centered Show more / Show less pattern.
